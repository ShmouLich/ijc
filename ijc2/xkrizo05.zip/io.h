#ifndef _IO_H_
#define _IO_H_

#include <stdio.h>
#include <ctype.h>

int get_word(char *word, int limit, FILE *fp);

#endif
