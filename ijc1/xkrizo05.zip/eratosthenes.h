/* 
 * IJC-DU1
 * eratosthenes.h
 * 
 * Datum vytvoření: 12.3.2020
 * Autor: Ondřej Kříž
 * Překladač: GCC
 */

#pragma once

#include "bitset.h"

void eratosthenes(bitset_t pole);
