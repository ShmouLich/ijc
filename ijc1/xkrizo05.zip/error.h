/* 
 * IJC-DU1
 * eratosthenes.c
 * 
 * Datum vytvoření: 14.3.2020
 * Autor: Ondřej Kříž
 * Překladač: GCC
 */

#pragma once

void warning_msg(const char *fmt, ...);

void error_exit(const char *fmt, ...);
